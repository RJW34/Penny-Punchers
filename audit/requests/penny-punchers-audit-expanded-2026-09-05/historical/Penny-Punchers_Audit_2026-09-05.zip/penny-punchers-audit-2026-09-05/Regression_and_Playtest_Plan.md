# Penny-Punchers — regression and playtest plan

This is a verification plan, not a record of tests already executed. Pin source and content before each run. Record both the unmodified failing build and the fixed build where practical. Do not weaken existing acceptance conditions to make the new tests pass.

## 1. Mandatory first regressions

### R1 — Combat/menu input separation (PP-001)
Launch the actual exported game, not only Core. Assign keyboard+pad, then two pads. In a live fight, inject and physically press every attack/chord button on both seats. Default B must start MK without opening Pause. Rebind B to LP and repeat. Start/Escape must still pause; B must still cancel in menus. Test transition frames and held-button suppression. The regression can first use software events, but physical confirmation remains separate.

### R2 — Full-separation camera containment (PP-002)
With legal directional inputs, walk both fighters away to the stage extremes. Record world positions and projected bounding silhouettes. Repeat with one stationary fighter, knockback, both palettes and jumps. Both must remain visible within the declared safe area. If a separation constraint changes combat geometry, put it in deterministic Core and rerun zoning, replay and network fixtures.

### R3 — Purchased capability coverage (PP-003–007)
For every rental, test selection → actual debit → actual recognizer input → actual move effect → expiry. Add a player-operable training loadout path. Separately verify that regular CPU-selected purchases have supported combat policies and that the lab correctly encodes `4+HP+HK`. Coverage of direct `TryStartAction` is not sufficient by itself, although existing command tests are valuable.

### R4 — Transparent preparation fallbacks (PP-008–013)
Exercise insufficient cash, replacing an expensive slot, altered reserve, out-of-time selection, both-ready on the same tick, late commit, duplicate commit and altered replay plans. Compare local/network screens and authoritative receipts. Users must see the exact plan that will commit; no silent full wipe or hidden replacement.

### R5 — Replays and failure paths (PP-027–031)
Load a second recording from a paused first one. Force save failure. Save twice within one second. Browse more than eight mixed private/local entries. Corrupt a late command, not only the header. All failures must preserve truthful status and leave the UI usable.

## 2. Source-derived combat hypotheses requiring execution

- Exact-frame command throw versus command throw, then command versus normal throw, both seat orders. Define the intended outcome before patching arbitration.
- Air parry one tick before landing into low/overhead/mid attacks. Inspect arm lifetime, recovery and ground eligibility.
- Forward parry plus taunt on the same tick; attack during taunt. Verify commitment clears or intentionally preserves defenses.
- Airborne cross-up while neutral versus during an attack; inspect facing epoch, sprite facing, charge history and command recognition.
- Standing-to-crouching and crouching-to-standing defense during blockstun and landing. Confirm posture, hurtboxes and actual guard agree.
- A late normal after the dummy becomes actionable must not pass a true-link drill. Unrelated earlier hits must not validate a blocked hit-confirm.

Use deterministic fixtures and legal input traces, but label fixture initialization distinctly from ordinary match input. Reproduce mirror cases. Do not promote a hypothesis to “fixed bug” without the failing behavior and intended rule.

## 3. Private networking

Use the existing fault injector, then two physical computers. Record baseline LAN behavior and separately inject delay, asymmetric jitter, loss, duplicates and reordering. Verify paid startup rollback, earlier/later terminal correction, clean quit, rematch, and pause/resume during prediction. Accounting and final results remain confirmed. Reversible local presentation may be predicted, but must have stable IDs and reconciliation. Capture contact-time versus displayed VFX coordinates.

Measure input delay, rollback depth/stalls and actual input-to-local-cue latency. An exported 60 FPS movie is not an input-latency measurement. A same-machine two-process test is not a two-PC certification.

## 4. Economy design experiments

First repair experiment policies and publish item/command coverage. Then use multiple seeds and more than one opponent policy. Analyze matched contexts, not independent-looking counts from mirrored duplicates. Investigate score-aware saving, cheap EX pressure, selected-super banking, per-round rentals, deliberate yielding, intentional draws, capped budgets and final-round cash-out. Disclose untested states and aborted runs.

Every item needs a tactical hypothesis, a base-kit comparison, and a counterplay example. Record purchase, execution, contact, consequences, remaining credits and next-round outcome. Do not use raw damage per credit as the only valuation; threat, knockdown, safety, uncertainty and timing matter.

The recorded 252 matches remain useful historical data. They are not invalidated merely because new gaps were found, but they should not be used to claim all-item or human competitive balance.

## 5. Human usability and feel sessions

Start with the owner and friend, then include additional players with different hardware and experience. Small sessions identify problems; they do not prove tournament balance.

Session A: no verbal shop coaching. Observe the first complete match. Ask each player what their purchase does, which input executes it, what it replaces, and what spending it prevents. Record every accidental timeout, reserve misunderstanding and incorrect input.

Session B: explain the rules, then run counterbalanced matches with saved plans and rental practice available. Ask the player to state the next-round plan before shopping. Record whether purchases change actual play and opponent responses.

Session C: compare the single-wallet game with rentals temporarily disabled against the improved shop configuration, keeping combat identical. This is a diagnostic experiment, not permission to discard the concept. Evaluate comprehension, interesting tradeoffs, pacing and desire to rematch.

Session D: combat feel only. Check walking/stopping, spacing, jump arcs, hitstop, links/cancels, parries, throws, reversal timing, guard changes and silhouettes on both sides. Keep a trace for every reported “my input did not come out” or “that should not hit.” Do not dismiss player feedback because a scripted test passes.

## 6. Art and presentation review

Collect actual current-build screenshots and normal-speed footage: title, select, both shop modes, reveal, neutral, hit, block, low/high/air/red parry, each rental, each super, mirror palettes, corners, maximum separation, pause, replay, result and rematch. This audit did not independently view that newest footage.

Use true-alpha checks over contrasting backgrounds. Review portrait aspect ratios, root/foot pivots, per-frame silhouettes, contact and recovery timing, animation holds, UI text lengths, reduced-flash behavior and event-time VFX. Inspect audio independently for cue distinction, mix hierarchy and repeated-sound fatigue.

## 7. Performance and release

Capture warm/cold loading and combat phase markers, frame times, GC, texture uploads and I/O. Attribute the recorded 557 ms-class outlier before calling it a combat hitch or declaring it harmless. Test normal rendering separately from movie capture and screenshot writes.

Fresh-build/export on the supported Windows/Linux environments, retain exact source/content/runtime hashes, then install into clean directories and run full matches. Treat WSLg/software-rendered Linux as that specific environment, not every Linux GPU/audio configuration. Verify notices, save errors, settings, hotplug and offline operation. Update all status documents from one current evidence record.

## Exit criteria

A dependable two-player duel, understandable and practiced economic decisions, no unexplained input loss/menu entry, visible fighters throughout legal play, attributable performance, responsive and readable effects, honest saved replays, completed actual-device checks, and an explicit recorded human verdict. A completion percentage or a green feature-count gate is not a substitute.
